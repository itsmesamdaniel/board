﻿/*==========================================================
    Author      : Sam Daniel S
    Date Created: 13 Jan 2016
    Description : Controller to handle Recent Projects page
    Change Log
    s.no      date    author     description     


 ===========================================================*/

dashboard.controller("RecentController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
    var vm = this;

    vm.recents = [
      {
          id: 1,
          heading: "Dashboard",
          title: "Angular Bootstrap Dashboard",
          description: "Angular Bootstrap Dashboard is a web dashboard application based on Bootstrap and AngularJS.",
          image: "dashboard",
          theme: "success",
          url: "dashboard.samdaniel.in",
          roles: [
              {
                  theme: "success",
                  myRole: "Individually Developed by Me"
              }
          ]
      },
      {
          id: 2,
          heading: "CRUD",
          title: "Simple CRUD Operations",
          description: "A Simple application based on Bootstrap and AngularJS perfoming CRUD operations in the front end.",
          image: "crud",
          theme: "danger",
          url: "crud.samdaniel.in",
          roles: [
              {
                  theme: "danger",
                  myRole: "Individually Developed by Me"
              }
          ]
      }
    ];

    console.log("coming to Recent controller");

}]);

