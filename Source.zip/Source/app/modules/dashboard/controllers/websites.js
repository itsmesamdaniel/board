﻿/*==========================================================
    Author      : Sam Daniel S
    Date Created: 13 Jan 2016
    Description : Controller to handle Websites page
    Change Log
    s.no      date    author     description     


 ===========================================================*/

dashboard.controller("WebsitesController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
    var vm = this;

    vm.websites = [
        {
            title: "My Website",
            image: "Sam",
            link: "http://samdaniel.in"
        },
        {
            title: "Mafigu Ministries",
            image: "mafigu",
            link: "http://mafigu.samdaniel.in/"
        },
        {
            title: "Pastor Jabez Christie",
            image: "jabez",
            link: "http://pastorjabezchristie.org"
        },
        {
            title: "MST Travels",
            image: "Travels",
            link: "http://www.msrtravels.in/"
        },
        {
            title: "Rescue Mission",
            image: "rescue",
            link: "http://www.rescuemissionministries.com/"
        },
        {
            title: "The Chennai Opticals",
            image: "chennaiopticals",
            link: "http://thechennaiopticals.com"
        },
        {
            title: "Namdhesa Makkal Katchi",
            image: "katchi",
            link: "http://namdhesammakkal.org/"
        },
        {
            title: "Lord Jesus Ministries",
            image: "ljm",
            link: "http://ljm.ranjithprabhu.in"
        },
        {
            title: "Karpagam University Symposium",
            image: "kite",
            link: "http://kite.ranjithprabhu.in"
        },
        {
            title: "Kode Work",
            image: "kodework",
            link: "http://mockup.ranjithprabhu.in"
        },
        {
            title: "Garments Today",
            image: "garment",
            link: "http://garmenttoday.in"
        },
        {
            title: "Chris Tools",
            image: "Chris",
            link: "http://christools.in"
        },
        {
            title: "Pearl Tools",
            image: "Pearl",
            link: "http://peraltools.samdaniel.in/"
        },
        {
            title: "Jeitree Real Estates",
            image: "Jeitree",
            link: "http://jeitree.samdaniel.in/"
        },
        {
            title: "Lighten Systems",
            image: "Lighten",
            link: "http://lightensystems.samdaniel.in/"
        }
    ];
    console.log("coming to Websites controller");

}]);

